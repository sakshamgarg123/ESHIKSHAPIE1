from django.contrib import admin
from .models import Course, Category, CategoryName, Instructor, EnrolledCourse, Review, Video, QuestionAnswer, Subject, StudyMaterial, user_profile, Contact, LoggedInUser

admin.site.register(Course)
admin.site.register(Category)
admin.site.register(CategoryName)
admin.site.register(Instructor)
admin.site.register(EnrolledCourse)
admin.site.register(Review)
admin.site.register(Video)
admin.site.register(QuestionAnswer)
admin.site.register(Subject)
admin.site.register(StudyMaterial)
admin.site.register(user_profile)
admin.site.register(Contact)
admin.site.register(LoggedInUser)